import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='justlam',
    application_name='nani',
    app_uid='ChN7F1TRdFWZ3LNH0S',
    org_uid='5cb50bb4-cf20-4e42-bf5e-22743a9f2cd9',
    deployment_uid='24f6aebe-f976-442f-8931-a0d5a503e9b8',
    service_name='nani',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'nani-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
