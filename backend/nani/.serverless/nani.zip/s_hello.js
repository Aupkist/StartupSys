
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'justlam',
  applicationName: 'nani',
  appUid: 'ChN7F1TRdFWZ3LNH0S',
  orgUid: '5cb50bb4-cf20-4e42-bf5e-22743a9f2cd9',
  deploymentUid: '77f044bf-b3b9-406a-a6a2-64426ba70a1d',
  serviceName: 'nani',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nani-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}